//week 11 --------------------------------------------------------------------------------------------------------------------

// function echo(msg){
//     return msg
// }

// function sum(...num){
//     let total = 0
//     for (const num of nums) {
//         total += num
//     }
//     return total
// }

// const MAX_VALUE = 100
// //common JS
// module.exports = {echo,sum, MAX_VALUE: MAX_VALUE}
// // console.log(sum(1,3,4,5))

//----------------------


// function echo(msg){
//     return msg
// }

// function sum(...num){
//     let total = 0
//     for (const num of nums) {
//         total += num
//     }
//     return total
// }

// const MAX_VALUE = 100
// //exportlist
// export{sum, echo, MAX_VALUE}

//week 12 --------------------------------------------------------------------------------------------------------------------
