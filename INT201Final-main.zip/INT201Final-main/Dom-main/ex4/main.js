// let messages = document.getElementsByClassName('message')

// for (let i = 0; i < messages.length; i++) {
//   messages[i].innerHTML = 'Too'
// }

// let messages = document.querySelectorAll('.message')
// messages.forEach((message) => {
//   messages[i].innerHTML = 'Too you'
// })

let messages = document.querySelector('#message-3') //class
messages[i].innerHTML = 'Too you'
